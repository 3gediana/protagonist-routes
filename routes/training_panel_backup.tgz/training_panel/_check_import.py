import agent, server
print("agent import OK; tools =", len(agent._tool_schemas()))
routes = [r.path for r in server.app.routes if "/api/agent" in getattr(r, "path", "")]
print("agent routes registered:", len(routes))
for p in sorted(routes):
    print("  ", p)
